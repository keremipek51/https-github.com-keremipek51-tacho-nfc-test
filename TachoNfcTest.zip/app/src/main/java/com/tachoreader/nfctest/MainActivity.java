package com.tachoreader.nfctest;

import android.app.*;
import android.os.*;
import android.nfc.*;
import android.nfc.tech.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView out;
    NfcAdapter nfc;
    PendingIntent pending;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,45,28,28);
        TextView title=new TextView(this); title.setText("Tacho NFC Test"); title.setTextSize(28); title.setTypeface(null,1);
        TextView info=new TextView(this); info.setText("\nKartı telefonun NFC antenine yaklaştır.\nBu test kartın hangi NFC teknolojilerini sunduğunu kontrol eder.\n");
        out=new TextView(this); out.setText("NFC durumu kontrol ediliyor..."); out.setTextSize(17);
        box.addView(title); box.addView(info); box.addView(out);
        setContentView(box);
        nfc=NfcAdapter.getDefaultAdapter(this);
        if(nfc==null) out.setText("❌ Bu telefonda NFC bulunamadı.");
        else if(!nfc.isEnabled()) out.setText("⚠️ NFC kapalı. Ayarlar'dan NFC'yi aç.");
        else out.setText("✅ NFC açık.\n\nKartı telefonun arkasına yaklaştır...");
        pending=PendingIntent.getActivity(this,0,new Intent(this,getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE);
    }
    @Override protected void onResume(){ super.onResume(); if(nfc!=null && nfc.isEnabled()) nfc.enableForegroundDispatch(this,pending,null,null); }
    @Override protected void onPause(){ if(nfc!=null) nfc.disableForegroundDispatch(this); super.onPause(); }
    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); Tag tag=intent.getParcelableExtra(NfcAdapter.EXTRA_TAG); if(tag!=null) showTag(tag); }
    void showTag(Tag tag){
        StringBuilder s=new StringBuilder("📡 KART ALGILANDI!\n\n");
        String[] tech=tag.getTechList();
        boolean iso=false;
        for(String t:tech){ s.append("✓ ").append(t.substring(t.lastIndexOf('.')+1)).append("\n"); if(t.equals(IsoDep.class.getName())) iso=true; }
        s.append("\n");
        if(iso){
            s.append("⭐ ISO-DEP / APDU desteği bulundu.\n");
            IsoDep d=IsoDep.get(tag);
            try { d.connect(); byte[] hi=d.getHistoricalBytes(); s.append("Bağlantı: başarılı\n"); s.append("Max transceive: ").append(d.getMaxTransceiveLength()).append(" byte\n");
                if(hi!=null && hi.length>0) s.append("Historical bytes: ").append(hex(hi)).append("\n");
                d.close();
            } catch(Exception e){ s.append("ISO-DEP bağlantısı kurulamadı: ").append(e.getClass().getSimpleName()).append("\n"); }
        } else s.append("ℹ️ ISO-DEP bulunmadı. Bu sonuç kartın temassız takograf arayüzü olmadığını gösterebilir.\n");
        s.append("\nNot: Bu test karttaki kişisel verileri okumaz; yalnızca NFC teknolojisini tespit eder.");
        out.setText(s.toString());
    }
    String hex(byte[] a){StringBuilder x=new StringBuilder(); for(byte b:a)x.append(String.format("%02X ",b)); return x.toString().trim();}
}
# Tacho NFC Test
Android test app. It detects NFC technologies exposed by a card and, if IsoDep is present, attempts a safe connection and reads only protocol metadata.
It does NOT read or store tachograph personal/activity data.
Build with Android Studio/Gradle.
